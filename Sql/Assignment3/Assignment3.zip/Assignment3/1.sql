select *
from instructor;