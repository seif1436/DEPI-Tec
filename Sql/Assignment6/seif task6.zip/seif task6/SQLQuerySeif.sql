USE ITI;

CREATE FUNCTION GetMonthName (@date DATE)
RETURNS VARCHAR(20)
AS
BEGIN
    RETURN DATENAME(MONTH, @date)
END

CREATE FUNCTION GetRangeValues (@start INT, @end INT)
RETURNS @Numbers TABLE (Number INT)
AS
BEGIN
    WHILE @start <= @end
    BEGIN
        INSERT INTO @Numbers VALUES (@start)
        SET @start += 1
    END
    RETURN
END

CREATE FUNCTION GetStudentDepartment (@StID INT)
RETURNS TABLE
AS
RETURN
    SELECT ISNULL(st_fname, '') + ' ' + ISNULL(st_lname, '') AS FullName,
           Dept_Name
    FROM Student
    JOIN Department ON Department.Dept_Id = Student.Dept_Id
    WHERE St_Id = @StID

DROP FUNCTION IF EXISTS CheckStudentName
CREATE FUNCTION CheckStudentName (@id INT)
RETURNS VARCHAR(100)
AS
BEGIN
    DECLARE @fname VARCHAR(50)
    DECLARE @lname VARCHAR(50)
    DECLARE @msg VARCHAR(100)

    SELECT @fname = st_fname, @lname = st_lname FROM Student WHERE St_Id = @id

    IF @fname IS NULL AND @lname IS NULL
        SET @msg = 'First name & last name are null'
    ELSE IF @fname IS NULL
        SET @msg = 'first name is null'
    ELSE IF @lname IS NULL
        SET @msg = 'last name is null'
    ELSE
        SET @msg = 'First name & last name are not null'

    RETURN @msg
END

CREATE FUNCTION FormatManagerHireDate (@format INT)
RETURNS TABLE
AS
RETURN
    SELECT Dept_Name, Ins_Name,
    FORMAT(Ins_HireDate, 
        CASE @format
            WHEN 1 THEN 'dd-MM-yyyy'
            WHEN 2 THEN 'MMMM yyyy'
            ELSE 'yyyy/MM/dd'
        END) AS FormattedDate
    FROM Instructor
    JOIN Department ON Instructor.Dept_Id = Department.Dept_Id
    WHERE Instructor.Ins_Manager IS NOT NULL

CREATE FUNCTION GetStudentInfo (@type VARCHAR(20))
RETURNS @result TABLE (Result VARCHAR(100))
AS
BEGIN
    IF @type = 'first name'
        INSERT INTO @result SELECT ISNULL(st_fname, '') FROM Student
    ELSE IF @type = 'last name'
        INSERT INTO @result SELECT ISNULL(st_lname, '') FROM Student
    ELSE IF @type = 'full name'
        INSERT INTO @result SELECT ISNULL(st_fname, '') + ' ' + ISNULL(st_lname, '') FROM Student
    RETURN
END

USE MyCompany;

CREATE FUNCTION EmployeesInProject (@pno INT)
RETURNS TABLE
AS
RETURN
    SELECT E.Fname + ' ' + E.Lname AS FullName, E.SSN, P.Pname
    FROM Works_on W
    JOIN Employee E ON E.SSN = W.ESSN
    JOIN Project P ON P.Pnumber = W.Pno
    WHERE W.Pno = @pno